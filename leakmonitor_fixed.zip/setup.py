from setuptools import setup, find_packages

setup(
    name="leakmonitor",
    version="0.2",
    packages=find_packages(),
    install_requires=["requests", "beautifulsoup4"],
    entry_points={
        'console_scripts': [
            'leakmonitor=leakmonitor.__main__:main',
        ],
    },
    author="Internal Red Team",
    description="Monitor publicly leaked credentials for your organization",
)