# LeakMonitor (Fixed)

A tool to monitor leaked credentials for an organization using public sources.

## Install

```bash
cd leakmonitor_fixed
pip install .
```

## Run

```bash
leakmonitor yourcompany.com --output output_folder
```