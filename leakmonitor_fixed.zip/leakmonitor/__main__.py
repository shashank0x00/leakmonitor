import argparse
from .main import run_monitor

def main():
    parser = argparse.ArgumentParser(description="Monitor public pastes for leaked credentials.")
    parser.add_argument("domain", help="Target domain (e.g. yourcompany.com)")
    parser.add_argument("--output", default="leaks", help="Directory to save results")
    args = parser.parse_args()
    run_monitor(args.domain, args.output)

if __name__ == "__main__":
    main()